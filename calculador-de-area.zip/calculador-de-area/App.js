import React, {useState} from 'react';
import { Text, SafeAreaView, StyleSheet, View, TextInput, TouchableOpacity } from 'react-native';

export default function App() {

  function CalcularArea(){
  const resultado = base * altura;
  alert('A área é ' + resultado)
}

    const [base, setBase] = useState('');
    const [altura, setAltura] = useState('');
  
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.paragraph}>
        Calculador de Área
      </Text>
      <TextInput style={styles.input} 
      placeholder='Insira o valor da Base da figura: '
      placeholderTextColor='#000'
      keyboardType='numeric'
      onChangeText={(base)=>setBase(base)}
      />

        
      <TextInput style={styles.input}
      placeholder='Insira a Altura da figura: '
      placeholderTextColor='#000'
      keyboardType='numeric'
      onChangeText={(altura)=>setAltura(altura)}
      />


      <TouchableOpacity style={styles.btn} onPress={CalcularArea}>
        <Text style={styles.textbtn}> Calcular a Área </Text>
      </TouchableOpacity>
      

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom:60
  },

  btn:{
    alignItems: 'center',
    backgroundColor:'#808080',
    padding:15,
    borderRadius:10,
    margin:15,
    marginTop:50,
  },
  textbtn:{
    fontSize:30,
    color:'#fff'
  },
  input:{
    fontSize:18,
    padding:20,
    backgroundColor:'#dc143c',
    borderRadius:10,
    margin:15,
    
  }
});
